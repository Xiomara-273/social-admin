import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../../../core/services/user.service';
import { User } from '../../../core/models/user.model';

@Component({
  selector: 'app-user-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './user-form.component.html',
  styleUrls: ['./user-form.component.css']
})
export class UserFormComponent implements OnInit {

  userId: number | null = null;
  isEdit = false;

  userForm = this.fb.group({
    name: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    role: ['', Validators.required],
    active: [true]
  });

  constructor(
    private fb: FormBuilder,
    private userService: UserService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    const idParam = this.route.snapshot.paramMap.get('id');
    this.userId = idParam ? Number(idParam) : null;

    if (this.userId) {
      const user = this.userService.getUserById(this.userId);

      if (user) {
        this.isEdit = true;
        this.userForm.patchValue(user);
      }
    }
  }

save(): void {
  if (this.userForm.invalid) return;

  const user: User = {
    id: this.userId ?? 0,
    name: this.userForm.value.name!,
    email: this.userForm.value.email!,
    role: this.userForm.value.role!,
    active: this.userForm.value.active!
  };

  if (this.isEdit) {
    this.userService.updateUser(user);
    alert('Usuario actualizado correctamente');
  } else {
    this.userService.addUser(user);
    alert('Usuario creado correctamente');
  }

  this.router.navigate(['/']);
}

  cancel(): void {
  const confirmCancel = confirm('¿Deseas cancelar y volver a la lista?');

  if (confirmCancel) {
    this.router.navigate(['/']);
  }
}

}