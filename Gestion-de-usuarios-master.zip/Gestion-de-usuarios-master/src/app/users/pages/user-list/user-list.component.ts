import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { UserService } from '../../../core/services/user.service';
import { User } from '../../../core/models/user.model';

@Component({
  selector: 'app-user-list',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})

export class UserListComponent implements OnInit {

  users: User[] = [];
  showInactive = false;

  constructor(
    private userService: UserService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadUsers();
  }

  loadUsers(): void {
    const allUsers = this.userService.getUsers();
    this.users = this.showInactive
      ? allUsers.filter(user => !user.active)
      : allUsers.filter(user => user.active);
  }

  toggleView(): void {
    this.showInactive = !this.showInactive;
    this.loadUsers();
  }

  deleteUser(id: number): void {
    if (confirm('¿Deseas desactivar este usuario?')) {
      this.userService.softDelete(id);
      this.loadUsers();
    }
  }

  reactivate(id: number): void {
    this.userService.reactivateUser(id);
    this.loadUsers();
  }

  edit(id: number): void {
    this.router.navigate(['/edit', id]);
  }
}
