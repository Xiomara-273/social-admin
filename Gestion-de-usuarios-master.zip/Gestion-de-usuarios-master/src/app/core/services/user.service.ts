import { Injectable } from '@angular/core';
import { User } from '../models/user.model';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private storageKey = 'users';

  constructor() {}

  // Obtener todos los usuarios (activos + inactivos)
  getUsers(): User[] {
    return this.readFromStorage();
  }

  // Obtener usuario por ID
  getUserById(id: number): User | undefined {
    return this.readFromStorage().find(u => u.id === id);
  }

  // Crear usuario
  addUser(user: User): void {
  const users = this.readFromStorage();
  user.id = this.generateId(users);
  user.active = true;
  users.push(user);
  this.saveToStorage(users);
}

  // Actualizar usuario
  updateUser(updatedUser: User): void {
    const users = this.readFromStorage().map(user =>
      user.id === updatedUser.id ? updatedUser : user
    );
    this.saveToStorage(users);
  }

  reactivateUser(id: number): void {
  const users = this.readFromStorage().map(user =>
    user.id === id ? { ...user, active: true } : user
  );
  this.saveToStorage(users);
}

  // Soft delete
  softDelete(id: number): void {
  const users = this.readFromStorage().map(user =>
    user.id === id ? { ...user, active: false } : user
  );
  this.saveToStorage(users);
}

  // ===== Helpers privados =====

  private readFromStorage(): User[] {
    const data = localStorage.getItem(this.storageKey);       
    return data ? JSON.parse(data) : [];
  }

  private saveToStorage(users: User[]): void {
    localStorage.setItem(this.storageKey, JSON.stringify(users));
  }

  private generateId(users: User[]): number {
    return users.length ? Math.max(...users.map(u => u.id)) + 1 : 1;
  }
}
